Flasky
======

This repository contains the source code examples for my O'Reilly book [Flask Web Development](http://www.flaskbook.com).

The commits and tags in this repository were carefully created to match the sequence in which concepts are presented in the book. Please read the section titled "How to Work with the Example Code" in the book's preface for instructions.

================
flask-wtf install

Get the Code
Flask-WTF is actively developed on GitHub, where the code is always available.

You can either clone the public repository:

git clone git://github.com/lepture/flask-wtf.git
Download the tarball:

$ curl -OL https://github.com/lepture/flask-wtf/tarball/master
Or, download the zipball:

$ curl -OL https://github.com/lepture/flask-wtf/zipball/master
Once you have a copy of the source, you can embed it in your Python package, or install it into your site-packages easily:

$ python setup.py install

=========================

pip install flask-login --upgrade


